﻿namespace BusinessLayer
{
    public class Class1
    {

    }
}